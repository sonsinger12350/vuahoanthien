<?php
/**
 * Wishlist items widget
 *
 * @author YITH <plugins@yithemes.com>
 * @package YITH\Wishlist\Templates\Wishlist\View
 * @version 3.0.0
 */

/**
 * Template variables:
 *
 * @var $before_widget          string HTML to print before widget
 * @var $after_widget           string HTML to print after widget
 * @var $instance               array Array of widget options
 * @var $products               array Array of items that were added to lists; each item refers to a product, and contains product object, wishlist items, and quantity count
 * @var $items                  array Array of raw items
 * @var $wishlist_url           string Url to wishlist page
 * @var $multi_wishlist_enabled bool Whether MultiWishlist is enabled or not
 * @var $default_wishlist       YITH_WCWL_Wishlist Default list
 * @var $add_all_to_cart_url    string Url to add all items to cart
 * @var $fragments_options      array Array of options to be used for fragments generation
 * @var $heading_icon           string Heading icon HTML tag
 */

if ( ! defined( 'YITH_WCWL' ) ) {
	exit;
} // Exit if accessed directly

$wishlist_url = home_url( 'san-pham-yeu-thich-cua-ban' );
// if( $user->ID>0 ) {
//   $wishlist_url = wc_get_account_endpoint_url( 'wishlist' );
// } else {
//   //$wishlist_url = home_url( 'wishlist' );
//   $wishlist_url = home_url( 'san-pham-yeu-thich-cua-ban' ); 
// }

?>

<?php echo apply_filters( 'yith_wcwl_before_wishlist_widget', $before_widget ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

<?php if ( ! empty( $instance['title'] ) ) : ?>
	<h3 class="widget-title"><?php echo esc_html( $instance['title'] ); ?></h3>
<?php endif; ?>

	<div
		class="content <?php echo esc_attr( $instance['style'] ); ?> yith-wcwl-items-<?php echo esc_html( $instance['unique_id'] ); ?> woocommerce wishlist-fragment on-first-load"
		data-fragment-options="<?php echo wc_esc_json( wp_json_encode( $fragments_options ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"
	>
		<div class="<?php echo (esc_html( count( $products )) > 0)?"hasCounting":""; ?>">
			<div class="heading">
				<div class="items-counter">
					<?php if ( 'mini' === $instance['style'] ) : ?>
					<a href="<?php echo esc_url( $wishlist_url ); ?>" class="nav-link d-flex align-items-center">
						<?php endif; ?>

						<?php /* ?>
						<span class="heading-icon">
							<?php echo yith_wcwl_kses_icon( apply_filters( 'yith_wcwl_widget_items_extended_heading_icon', $heading_icon ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</span>
						<?php */ ?>
						<i class="bi bi-heart"></i>
						<span class="d-none d-xl-inline col-02">
							<b>Yêu thích</b><br>
						<?php if ( ! $instance['ajax_loading'] && isset( $instance['show_count'] ) && 'yes' === $instance['show_count'] ) : ?>
							<small class="items-count">
								<?php echo esc_html( count( $products ) ); ?> sản phẩm
							</small>
						<?php endif; ?>

						<?php if ( 'mini' === $instance['style'] ) : ?>
					</a>
				<?php endif; ?>
				</div>

				<?php if ( isset( $instance['style'] ) && 'extended' === $instance['style'] ) : ?>
					<h3 class="heading-title"><?php echo esc_html( apply_filters( 'yith_wcwl_widget_items_extended_title', __( 'Wishlist', 'yith-woocommerce-wishlist' ) ) ); ?></h3>
				<?php endif; ?>
			</div>

			<div class="list">
				<?php if ( ! $instance['ajax_loading'] && isset( $instance['show_count'] ) && 'yes' === $instance['show_count'] && 'mini' === $instance['style'] && count( $products ) ) : ?>
					<p class="items-count">
						<?php
						// translators: 1. Number of items in wishlist.
						echo esc_html( sprintf( __( '%d items in wishlist', 'yith-woocommerce-wishlist' ), count( $products ) ) );
						?>
					</p>
				<?php endif; ?>

				<?php if ( ! $instance['ajax_loading'] && ! empty( $products ) ) : ?>
					<ul class="cart_list product_list_widget">
						<?php
						foreach ( $products as $product_id => $info ) :
							/**
							 * Each of products added to wishlists.
							 *
							 * @var $product \WC_Product
							 */
							$product = $info['product'];
							?>
							<li>
								<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'remove_from_wishlist', $product_id ), 'remove_from_wishlist' ) ); ?>" class="remove_from_all_wishlists" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-wishlist-id="<?php echo 'yes' === $instance['show_default_only'] ? esc_attr( $default_wishlist->get_id() ) : ''; ?>">&times;</a>
								<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="image-thumb">
									<?php echo wp_kses_post( $product->get_image() ); ?>
								</a>
								<div class="mini-cart-item-info">
									<a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_title() ); ?></a>

									<span class="min-cart-subtotal">
										<?php echo wp_kses_post( sprintf( '%d x %s', $info['quantity'], $product->get_price_html() ) ); ?>
									</span>

									<?php if ( 'yes' !== $instance['show_default_only'] ) : ?>
										<small class="mini-cart-wishlist-info">
											<?php echo wp_kses_post( sprintf( '%s: %s', esc_html__( 'In', 'yith-woocommerce-wishlist' ), implode( ', ', $info['in_list'] ) ) ); ?>
										</small>
									<?php endif; ?>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="empty-wishlist">
						<?php echo esc_html( apply_filters( 'yith_wcwl_widget_items_empty_list', __( 'Please, add your first item to the wishlist', 'yith-woocommerce-wishlist' ) ) ); ?>
					</p>
				<?php endif; ?>

				<?php if ( count( $products ) && 'yes' === $instance['show_view_link'] ) : ?>
					<a class="show-wishlist" href="<?php echo esc_url( $wishlist_url ); ?> "><?php esc_html_e( 'View your wishlist &rsaquo;', 'yith-woocommerce-wishlist' ); ?></a>
				<?php endif; ?>

				<?php if ( count( $products ) && 'yes' === $instance['show_add_all_to_cart'] ) : ?>
					<a class="btn button alt add_all_to_cart" href="<?php echo esc_url( $add_all_to_cart_url ); ?>"><?php esc_html_e( 'Add all to cart', 'yith-woocommerce-wishlist' ); ?></a>
				<?php endif; ?>
			</div>

		</div>
	</div>

<?php echo apply_filters( 'yith_wcwl_after_wishlist_widget', $after_widget ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
