<?php


// $products = array();

// $categories = get_the_terms( get_the_ID(), 'product_cat' );
// if( is_object($categories[0]) ) 
// {
//   $cat = $categories[0];

//   $cat_root = site_wc_get_terms_to_root( $cat, 1 );
  
//   $exclude = array();

//   if( $cat->parent != $cat_root->term_id ) {
//     $exclude[] = $cat->parent;
//   } else {
//     $exclude[] = $cat->term_id;
//   }

//   $terms = get_terms( array(
//     'taxonomy'=> $cat_root->taxonomy,
//     'parent'  => $cat_root->term_id,
//     'exclude' => $exclude
//   ) );
  
//   $limit = 6;

//   foreach( $terms as $term ) {
//     $list = wc_get_products(array(
//       'category' => array( $term->name ),
//       'limit' => 1
//     ));

//     if( count($list)>0 ) {
//       $products[] = $list[0];
//     }

//     if( count($products)>=$limit ) {
//       break;
//     }
//   }
// }

$products = array();

$current_product_id = get_the_ID();
$current_product_brands = wp_get_post_terms($current_product_id, 'product-brand', array('fields' => 'names'));

$categories = get_the_terms($current_product_id, 'product_cat');
if (!empty($categories) && is_object($categories[0])) {
    $cat = $categories[0];
    $cat_root = site_wc_get_terms_to_root($cat, 1);

    $exclude = array();

    if ($cat->parent != $cat_root->term_id) {
        $exclude[] = $cat->parent;
    } else {
        $exclude[] = $cat->term_id;
    }

    $terms = get_terms(array(
        'taxonomy' => $cat_root->taxonomy,
        'parent'   => $cat_root->term_id,
        'exclude'  => $exclude
    ));

    //var_dump($terms);

    $limit = 15;
    $products_per_term = array();
    $terms_with_products = 0;

    foreach ($terms as $term) {
        // $args = array(
        //     'category' => array($term->name),
        //     'orderby' => 'rand',
        //     'limit'    => 5, // Initially, set the limit to maximum
        //     'tax_query' => array(
        //         array(
        //             'taxonomy' => 'product-brand',
        //             'field'    => 'slug',
        //             'terms'    => $current_product_brands,
        //         ),
        //     ),
        // );
        // $list = wc_get_products($args);

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10, // Fetch more initially to filter later
            'orderby' => 'rand',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'slug',
                    'terms'    => array($term->name),
                ),
                array(
                    'taxonomy' => 'product-brand',
                    'field'    => 'slug',
                    'terms'    => $current_product_brands,
                ),
            ),
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_regular_price',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
                array(
                    'key' => '_sale_price',
                    'compare' => 'EXISTS', // Ensure sale price exists
                ),
                array(
                    'key' => '_sale_price',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
        );

        $list = get_posts($args);

        //var_dump($list);   

        if (count($list) > 0) {
            $terms_with_products++;
            $limit_per_cate = ($terms_with_products < 5) ? 5 : 1;
            $products_per_term[$term->name] = array_slice($list, 0, $limit_per_cate);

            if (count($products) + count($products_per_term[$term->name]) > $limit) {
                break;
            }

            $products = array_merge($products, $products_per_term[$term->name]);
        }

        if (count($products) >= $limit) {
            break;
        }
    }

    // Shuffle the products array to randomize the order
    shuffle($products);

    // Limit the final product array to the required limit
    $products = array_slice($products, 0, $limit);
}


?>
<?php if ( count($products) > 0 ): ?>
<div class="section list-product-buy-with">
  <div class="container">
    <div class="section-bg">
        <h2 class="section-header border-0">
          <span>Sản phẩm thường mua kèm</span>
        </h2>
        <div class="slide-multiple slide-product">
          <?php 
            foreach( $products as $product ): 

              if( isset($product->ID) ) {
                $product = wc_get_product( $product->ID ); 
              }

              site_setup_product_data( $product ); 
            
              wc_get_template_part( 'archive/product', 'item' );
              
            endforeach;
            site_reset_product_data();
          ?>
        </div>
    </div>
  </div>
</div>
<?php endif ?>
